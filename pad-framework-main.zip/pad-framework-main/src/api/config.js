// PAD Cloud config, don't alter
const serverPort = 3000;
const baseUrl = `${location.protocol}//${location.hostname}:${serverPort}`;